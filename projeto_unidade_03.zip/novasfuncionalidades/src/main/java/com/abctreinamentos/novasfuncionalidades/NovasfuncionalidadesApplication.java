package com.abctreinamentos.novasfuncionalidades;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NovasfuncionalidadesApplication {

	public static void main(String[] args) {
		SpringApplication.run(NovasfuncionalidadesApplication.class, args);
	}
}
