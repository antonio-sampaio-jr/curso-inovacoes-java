package com.abctreinamentos.novasfuncionalidades.controller;

import java.time.LocalDate;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.abctreinamentos.novasfuncionalidades.entity.Funcionario;
import com.abctreinamentos.novasfuncionalidades.service.FuncionarioService;

@RestController
public class FuncionarioController {
	
	@Autowired
	private FuncionarioService funcionarioService;
	
	@GetMapping("/")
	public ResponseEntity<String> inicio()
	{
		String response = """
				<html>
					<body>
						<a href="/listarFuncionarios">1. Listar Funcionários</a> <br />
						<a href="/listarCidadesFuncionarios">2. Listar Cidades Funcionários</a> <br />
						<a href="/calcularFolhaFuncionarios">3. Calcular Folha Funcionários</a> <br />
						<a href="/listarFuncionariosIdadeMenor30">4. Listar Funcionários Idade < 30</a> <br />
						<a href="/listarFuncionariosIdadeMaiorIgual30">4. Listar Funcionários Idade >= 30</a> <br />
					    <a href="/listarFuncionarioMaiorSalario">5. Listar Funcionário Maior Salário</a> <br />
					    <a href="/listarFuncionarioMenorSalario">6. Listar Funcionário Menor Salário</a> <br />
					    <a href="/listarSalariosFuncionariosOrdenados">7. Listar Salários Funcionários Ordenados</a> <br />
					    <a href="/listarAnoNascimentoFuncionarioMaisAntigo">8. Listar Ano Funcionário Mais Antigo</a> <br /> 	    
		                <a href="/listarSalariosFuncionariosOrdenadosSimplificado">9. Listar Salários Funcionários Ordenados - Simplificado</a> <br />		
					</body>
				</html>
				""";
		
		return new ResponseEntity<String>(response,HttpStatus.OK);	
	}
	
	
	@GetMapping("/listarFuncionarios")
	public ResponseEntity<List<Funcionario>> listarFuncionarios()
	{
		List<Funcionario> funcionarios = funcionarioService.listAll();
		return new ResponseEntity<List<Funcionario>>(funcionarios,HttpStatus.OK);	
	}
	
	@GetMapping("/listarCidadesFuncionarios")
	public ResponseEntity<List<String>> listarCidadesFuncionarios()
	{
		var funcionarios = funcionarioService.listAll();
		
	    var cidades = funcionarios.stream().map(Funcionario::getCidade).toList();
		
		return new ResponseEntity<List<String>>(cidades,HttpStatus.OK);	
	}
	
	@GetMapping("/calcularFolhaFuncionarios")
	public ResponseEntity<String> calcularFolhaFuncionarios()
	{
		List<Funcionario> funcionarios = funcionarioService.listAll();
		
		double somaSalarios = funcionarios.stream().mapToDouble(Funcionario::getSalario).sum();
		
		//Java 13 -> Text Blocks
		String resposta = """
				{
					"Total da Folha de Pagamentos": %.2f
				}
				""".formatted(somaSalarios);
		
		
		return new ResponseEntity<String>(resposta,HttpStatus.OK);	
	}
	
	@GetMapping("/listarFuncionariosIdadeMenor30")
	public ResponseEntity<String> listarFuncionariosIdadeMenor30()
	{
		List<Funcionario> funcionarios = funcionarioService.listAll();
		
		long totalFuncionarios = funcionarios.stream().filter(f -> f.getIdade() < 30).count();
		double somaSalarios = funcionarios.stream().
				filter(f -> f.getIdade() < 30).mapToDouble(Funcionario::getSalario).sum();
		
		double mediaSalarial = somaSalarios/totalFuncionarios;
		
		//Java 13 -> Text Blocks
		String resposta = """
				{
					"Total de Funcionários < 30 anos": %d,
					"Média Salarial": %.2f
				}
				""".formatted(totalFuncionarios,mediaSalarial);
		
		
		return new ResponseEntity<String>(resposta,HttpStatus.OK);	
	}
	
	@GetMapping("/listarFuncionariosIdadeMaiorIgual30")
	public ResponseEntity<String> listarFuncionariosIdadeMaiorIgual30()
	{
		List<Funcionario> funcionarios = funcionarioService.listAll();
		
		long totalFuncionarios = funcionarios.stream().filter(f -> f.getIdade() >= 30).count();
		double somaSalarios = funcionarios.stream().
				filter(f -> f.getIdade() >= 30).mapToDouble(Funcionario::getSalario).sum();
		
		double mediaSalarial = somaSalarios/totalFuncionarios;
		
		//Java 13 -> Text Blocks
		String resposta = """
				{
					"Total de Funcionários >= 30 anos": %d,
					"Média Salarial": %.2f
				}
				""".formatted(totalFuncionarios,mediaSalarial);
		
		
		return new ResponseEntity<String>(resposta,HttpStatus.OK);	
	}
	
	@GetMapping("/listarFuncionarioMaiorSalario")
	public ResponseEntity<Optional<Funcionario>> listarFuncionarioMaiorSalario()
	{
		List<Funcionario> funcionarios = funcionarioService.listAll();
		
		Optional<Funcionario> funcionario = funcionarios.stream().
				reduce((f1,f2)->f1.getSalario()>f2.getSalario() ? f1:f2);
		
		return new ResponseEntity<Optional<Funcionario>>(funcionario,HttpStatus.OK);	
	}
	
	@GetMapping("/listarFuncionarioMenorSalario")
	public ResponseEntity<Optional<Funcionario>> listarFuncionarioMenorSalario()
	{
		List<Funcionario> funcionarios = funcionarioService.listAll();
		
		Optional<Funcionario> funcionario = funcionarios.stream().
				reduce((f1,f2)->f1.getSalario() < f2.getSalario() ? f1:f2);
		
		return new ResponseEntity<Optional<Funcionario>>(funcionario,HttpStatus.OK);	
	}
	
	@GetMapping("/listarSalariosFuncionariosOrdenados")
	public ResponseEntity<List<Funcionario>> listarSalariosFuncionariosOrdenados()
	{
		List<Funcionario> funcionarios = funcionarioService.listAll().stream().
				sorted((f1,f2)->Double.compare(f1.getSalario(), f2.getSalario())).toList();
		
		return new ResponseEntity<List<Funcionario>>(funcionarios,HttpStatus.OK);	
	}
	
	@GetMapping("/listarSalariosFuncionariosOrdenadosSimplificado")
	public ResponseEntity<Map<?,?>> listarSalariosFuncionariosOrdenadosSimplificado()
	{
		List<Funcionario> funcionarios = funcionarioService.listAll().stream().
				sorted((f1,f2)->Double.compare(f1.getSalario(), f2.getSalario())).toList();
		
		var nomeSalarioMap = new LinkedHashMap<>();
		
		funcionarios.forEach(funcionario -> nomeSalarioMap.put(funcionario.getNome(),funcionario.getSalario()));
		
		return new ResponseEntity<>(nomeSalarioMap,HttpStatus.OK);	
	}
	
	@GetMapping("/listarAnoNascimentoFuncionarioMaisAntigo")
	public ResponseEntity<String> listarAnoNascimentoFuncionarioMaisAntigo()
	{
		var funcionarios = funcionarioService.listAll();
		
		Optional<Funcionario> funcionario = funcionarios.stream().
				reduce((f1,f2)->f1.getIdade() > f2.getIdade() ? f1:f2);
		
		int maiorIdade = 0;
		String nome = "";
		
		if(funcionario.isPresent())
		{
			maiorIdade = funcionario.get().getIdade();
			nome = funcionario.get().getNome();
		}	
		
		LocalDate dataHoje = LocalDate.now();
        
        int anoNascimentoProvavel = dataHoje.getYear() - maiorIdade;
      
        String resposta = """
				{
					"Nome do Funcionário Mais Antigo": %s,
					"Provável Ano de Nascimento": %d
				}
				""".formatted(nome,anoNascimentoProvavel);
		
		
		return new ResponseEntity<String>(resposta,HttpStatus.OK);
	}
	
}
