package novidadesJava8_10;

import java.util.List;
import java.util.Map;
import java.util.Set;

public class Java9 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		exemplo01();
	}
	
	//Unidade 03 -> Collection Factory -> Slide 36
	public static void exemplo01()
	{
		//List.of()
		List<String> list = List.of("maçã", "banana", "uva");

		//Set.of()
		Set<Integer> set = Set.of(1,2,3,4,5);

		//Map.of()
		Map<String, Integer> map = Map.of("um", 1, "dois", 2, "três", 3);
	}

}
