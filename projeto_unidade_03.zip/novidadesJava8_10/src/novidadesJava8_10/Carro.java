package novidadesJava8_10;

public class Carro implements Veiculo {

	@Override
	public void acelarar(int velocidade) {
		// TODO Auto-generated method stub

	}

	@Override
	public void frear() {
		// TODO Auto-generated method stub

	}

}
