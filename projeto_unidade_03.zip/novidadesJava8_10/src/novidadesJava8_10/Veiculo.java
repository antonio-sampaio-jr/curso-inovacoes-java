package novidadesJava8_10;

public interface Veiculo {

	void acelarar(int velocidade);
	void frear();
	
	default int getVelocidadeAtual()
	{
		return 0;
	}
	
	static boolean estaEmMovimento(int velocidade)
	{
		mensagem();
		return velocidade > 0;
	}
	
	//Unidade 03 -> Métodos Privados -> Slide 45
	private static void mensagem()
	{
		System.out.println("Se estiver em movimento, retorna true; caso contrário, retorna false");
	}
	
}

