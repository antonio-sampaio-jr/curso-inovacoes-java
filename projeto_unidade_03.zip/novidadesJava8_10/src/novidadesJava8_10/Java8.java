package novidadesJava8_10;

import java.time.LocalDate;
import java.time.Month;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class Java8 {
	
	
	public static void main(String[] args) {
		exemplo10();
	}
	
	//Unidade 03 -> Lambdas -> Slide 8
	public static void exemplo01()
	{
		List<Integer> integers = Arrays.asList(1,2,3,4,5);
		integers.forEach(x->System.out.println(x));
	}
	
	//Unidade 03 -> Lambdas -> Slide 8
	public static void exemplo02()
	{
		List<Integer> integers = Arrays.asList(1,2,3,4,5);
		integers.forEach(x->
		{
			x = x + 10;
			System.out.println(x);
		});	
	}
	
	//Unidade 03 -> Referência de Métodos -> Slide 8
	public static void exemplo03()
	{
			List<Integer> integers = Arrays.asList(1,2,3,4,5);
			integers.forEach(System.out::println);	
	}
	
	//Unidade 03 -> Streams -> Map -> Slide 19
	public static void exemplo04()
	{
		List<Integer> numeros = Arrays.asList(1,2,3,4,5);

		List<Integer> quadrados = numeros.stream()
	        .map(numero -> numero * numero)
	        .collect(Collectors.toList());

		System.out.println(quadrados); 
	}
	
	//Unidade 03 -> Streams -> Filter -> Slide 21
	public static void exemplo05()
	{
		List<Integer> numeros = Arrays.asList(1,2,3,4,5);

		List<Integer> numerosPares = numeros.stream()
		        .filter(numero -> numero % 2 == 0)
		        .collect(Collectors.toList());

		System.out.println(numerosPares); 
	}
	
	//Unidade 03 -> Streams -> Reduce -> Slide 23
	public static void exemplo06()
	{
		List<Integer> numbers = Arrays.asList(1,2,3,4,5);

		int sum = numbers.stream()
		                 .reduce(0, (a, b) -> a + b);
		//Usando o método reduce para somar todos os elementos

		System.out.println("Soma: " + sum);  
	}
	
	//Unidade 03 -> Streams -> Sorted -> Slide 25
	public static void exemplo07()
	{
		List<Integer> numbers = Arrays.asList(5,2,8,1,3);

		List<Integer> sortedNumbers = numbers.stream()
		                                     .sorted()
		                                     .collect(Collectors.toList());

		System.out.println(sortedNumbers);  	
	}

	//Unidade 03 -> Streams -> Count -> Slide 26
	public static void exemplo08()
	{
		List<Integer> numbers = Arrays.asList(1,2,3,4,5,6,7,8,9,10);

		long totalCount = numbers.stream().count();

		System.out.println("Total de números: " + totalCount);  
	}
	
	//Unidade 03 -> Streams -> Sum -> Slide 27
	public static void exemplo09()
	{
		IntStream numbers = IntStream.of(1,2,3,4,5);

		int sum = numbers.sum();

		System.out.println("Soma dos números: " + sum);  
	}
	
	//Unidade 03 -> Streams -> java.time -> Slide 32
	public static void exemplo10()
	{
		LocalDate hoje = LocalDate.now();
		
        System.out.println("Hoje é: " + hoje);
        
        int idade = 28;
        
        int anoNascimentoProvavel = hoje.getYear() - idade;
        
        System.out.println(anoNascimentoProvavel);

        LocalDate aniversario = LocalDate.of(1975, Month.DECEMBER, 22);
        // Criar um DateTimeFormatter com o padrão desejado
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd 'de' MMMM 'de' yyyy");
        
        // Formatar a data usando o formatter
        String dataFormatada = aniversario.format(formatter);
    
        System.out.println("Aniversário: " + dataFormatada);

        //int idade = aniversario.until(hoje).getYears();
        System.out.println("Idade: " + idade);
	}
}
