package novidadesJava8_10;

import java.util.List;
import java.util.Map;
import java.util.Set;

public class Java10 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
	
	//Unidade 03 -> Tipo var -> Slide 50
	public static void exemplo01()
	{
		//List.of()
		var list = List.of("maçã", "banana", "uva");

		//Set.of()
		var set = Set.of(1,2,3,4,5);

		//Map.of()
		var map = Map.of("um", 1, "dois", 2, "três", 3);

	}

}
