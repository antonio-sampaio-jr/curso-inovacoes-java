package novidadesJava17.aux;

public record Circulo(double raio) implements IFormaGeomatrica {
	
	public String tipo() {
		return "Circulo";
	}	 	
}