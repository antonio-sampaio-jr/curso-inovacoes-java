package novidadesJava17.aux;

public record Retangulo(double largura, double altura) 
	implements IFormaGeomatrica {

	public String tipo() {
		return "Retangulo";
	} 
}