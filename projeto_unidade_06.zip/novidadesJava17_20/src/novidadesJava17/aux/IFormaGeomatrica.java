package novidadesJava17.aux;

public interface IFormaGeomatrica {
	String tipo();
}
