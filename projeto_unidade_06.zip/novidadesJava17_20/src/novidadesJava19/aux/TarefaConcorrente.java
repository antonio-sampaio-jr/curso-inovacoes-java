package novidadesJava19.aux;

public class TarefaConcorrente implements Runnable {
    private final int id;

    public TarefaConcorrente(int id) {
        this.id = id;
    }

    @Override
    public void run() {
        System.out.println("Tarefa " + id + " iniciada.");
        // Coloque aqui o código da tarefa que será executada concorrentemente

        try {
            // Simula o processamento da tarefa
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }

        System.out.println("Tarefa " + id + " concluída.");
    }
}
