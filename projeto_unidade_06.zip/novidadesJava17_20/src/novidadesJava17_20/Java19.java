package novidadesJava17_20;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import jdk.incubator.concurrent.StructuredTaskScope;
import novidadesJava19.aux.TarefaConcorrente;

public class Java19 {

	public static void main(String[] args) {
		exemplo04();
	}
	
	//Unidade 06 -> Threads Virtuais -> Slide 26
	public static void exemplo01()
	{
		// Objeto Runnable "comum
		Runnable thread = () -> System.out.printf("Olá! Estou rodando em %s \n", Thread.currentThread());

		// Execução de uma thread "comum" com o Runnable "comum"
		Executors.newSingleThreadExecutor().execute(thread);

		// Execução de uma virtual thread com o mesmo Runnable "comum"        
		Executors.newVirtualThreadPerTaskExecutor().execute(thread);		
	}
	
	//Unidade 06 -> Future -> Slide 32
	public static void exemplo02()
	{
		CompletableFuture<String> futuro = CompletableFuture.supplyAsync(() -> {
            // Simula uma operação assíncrona
            return "Resultado da operação assíncrona";
        });

        futuro.thenAccept(resultado -> {
            System.out.println("Resultado: " + resultado);
        });
	}
	
	//Unidade 06 -> Concorrência Não Estruturada -> Slide 33
	public static void exemplo03()
	{
		// Cria um ExecutorService com 3 threads
        ExecutorService executor = Executors.newFixedThreadPool(3);

        // Executa tarefas concorrentes
        for (int i = 0; i < 5; i++) {
            executor.execute(new TarefaConcorrente(i));
        }

        // Encerra o ExecutorService quando não precisar mais dele
        executor.shutdown();	
	}
	
	//Unidade 06 -> Concorrência Estruturada -> Slide 34
	public static void exemplo04()
	{
		try (var scope = new StructuredTaskScope<>()) 
		{
		   Future<TarefaConcorrente> thread1 = scope.fork(()->new TarefaConcorrente(1));
		   Future<TarefaConcorrente> thread2 = scope.fork(()->new TarefaConcorrente(2));
		   Future<TarefaConcorrente> thread3 = scope.fork(()->new TarefaConcorrente(3));
		   scope.join();
		   System.out.println(thread1.resultNow());
		   System.out.println(thread2.resultNow());
		   System.out.println(thread3.resultNow());
		} 
		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
