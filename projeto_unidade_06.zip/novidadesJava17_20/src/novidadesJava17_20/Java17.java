package novidadesJava17_20;

import java.util.random.RandomGenerator;
import java.util.random.RandomGeneratorFactory;

import novidadesJava17.aux.IFormaGeomatrica;
import novidadesJava17.aux.Retangulo;
import novidadesJava17.aux.Circulo;

public class Java17 {

	
	public static void main(String[] args) {
		exemplo03();
	}
	
	//Unidade 06 -> Novos Algoritmos PRNG -> Slide 9
	public static void exemplo01()
	{
		RandomGeneratorFactory.all()
        .map(fac -> fac.group()+ " : " +fac.name())
        .sorted()
        .forEach(System.out::println);
	}
	
	//Unidade 06 -> Algoritmo Xoshiro256PlusPlus PRNG -> Slide 9
	public static void exemplo02()
	{
		RandomGenerator randomGenerator = 
				RandomGeneratorFactory.of("Xoshiro256PlusPlus").create(999);

	      System.out.println(randomGenerator.getClass());

	      int cont = 0;
	      while(cont<=10){
	          // 0-10
	          int resultado = randomGenerator.nextInt(11);
	          System.out.println(resultado);
	          cont++;
	      }
	}
	
	//Unidade 06 -> Pattern Matching para Switch -> Slide 10
	public static void exemplo03()	
	{
		
		IFormaGeomatrica forma = new Retangulo(2,5);
		
		//IFormaGeomatrica forma = new Circulo(5);
		
		
		if (forma instanceof Retangulo retangulo) { //Record Pattern
		    System.out.println("Área do Retângulo:"
		    +retangulo.altura()*retangulo.largura());
		}
		else if (forma instanceof Circulo circulo) {
		    System.out.println("Área do Círculo:"
		    +circulo.raio()*circulo.raio()*Math.PI);
		}
		
		System.out.printf("%.2f",getPerimetro(forma));
		
	}
	
    public static double getPerimetro(IFormaGeomatrica forma) 
    		                throws IllegalArgumentException {
        
    	return switch (forma.tipo()) {
            case "Retangulo" -> {
            	Retangulo r = (Retangulo)forma;
            	yield 2 * r.altura() + 2 * r.largura();
            }
            case "Circulo"   -> {
            	Circulo c = (Circulo)forma;
            	yield 2 * c.raio() * Math.PI;
            }
            default          -> 
                throw new IllegalArgumentException("Forma não reconhecida!");
        };
    }
	
}
