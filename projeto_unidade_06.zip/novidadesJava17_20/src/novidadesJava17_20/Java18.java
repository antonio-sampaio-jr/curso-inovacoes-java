package novidadesJava17_20;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.nio.charset.Charset;

public class Java18 {

	public static void main(String[] args) {
		exemplo01();
	}
	
	//Unidade 06 -> UTF-8 Padrão -> Slide 15
	public static void exemplo01()
	{
		//Padrão de charset
		System.out.println("Default charset : " + 
				Charset.defaultCharset());
		System.out.println("file.encoding   : " + 
				System.getProperty("file.encoding"));
		System.out.println("native.encoding : " + 
				System.getProperty("native.encoding"));
	}
	
	//Unidade 06 -> UTF-8 Padrão -> Slide 15
	public static void exemplo02()
	{
		try (FileWriter fw = new FileWriter("happy-coding.txt");
			    BufferedWriter bw = new BufferedWriter(fw)) {
			  bw.write("ハッピーコーディング！");
			}
		catch(Exception e) {System.out.println(e.getMessage());}
	}
	
}
