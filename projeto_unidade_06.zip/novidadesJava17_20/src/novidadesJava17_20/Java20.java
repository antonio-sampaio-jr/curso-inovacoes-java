package novidadesJava17_20;

import jdk.incubator.concurrent.ScopedValue;

public class Java20 {

	public static ScopedValue<String> scopedValue = ScopedValue.newInstance();
	
	public static void main(String[] args) {
	  	
		Java20 instance = new Java20();
		
		ScopedValue.where(scopedValue, "Antonio Sampaio Jr", () -> {
			System.out.println("Valor é: " + scopedValue.get());
			instance.doSomething();
	    });
		
		ScopedValue.where(scopedValue, "Antonio Benedito", () -> {
			System.out.println("Valor é: " + scopedValue.get());
			instance.doSomething();
	    });
	}

	public void doSomething() {
	  System.out.println("Acessando o valor <scoped value>: " + scopedValue.get());
	}
}
