package novidadesJava20.aux;

public class ExemploThreadLocal {

    // Cria um ThreadLocal para armazenar nomes
    private static ThreadLocal<String> nomeThreadLocal = new ThreadLocal<>();

    public static void main(String[] args) {
        // Cria threads
        Thread thread1 = new Thread(new Usuario("Thread 1"));
        Thread thread2 = new Thread(new Usuario("Thread 2"));

        // Inicia as threads
        thread1.start();
        thread2.start();
    }

    static class Usuario implements Runnable {
        private String nome;

        public Usuario(String nome) {
            this.nome = nome;
        }

        @Override
        public void run() {
            // Define o nome da thread atual no ThreadLocal
            nomeThreadLocal.set(nome);

            // Obtém e imprime o nome da thread atual a partir do ThreadLocal
            System.out.println("Nome na Thread " + nome + ": " + nomeThreadLocal.get());
        }
    }
}
