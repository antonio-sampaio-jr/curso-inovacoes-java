package com.abctreinamentos.novasfuncionalidades.aux.novaversao;

public record RMarketing (String nomeCampanha, String descricaoCampanha, double orcamento)
	implements IDepartamento{
		

}
