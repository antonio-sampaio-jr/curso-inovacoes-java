package com.abctreinamentos.novasfuncionalidades.entity;

import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection="funcionarios")
public record Funcionario(String nome,
        int idade,
        String cargo,
        String departamento,
        String cidade,
        String estado,
        String formatoTrabalho,
        double salario) 
{

}
