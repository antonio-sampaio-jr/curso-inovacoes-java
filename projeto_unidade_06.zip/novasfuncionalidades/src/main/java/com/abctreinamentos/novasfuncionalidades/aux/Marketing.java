package com.abctreinamentos.novasfuncionalidades.aux;

public final class Marketing extends Departamento {
	
	private String nomeCampanha;
    private String descricaoCampanha;
    private double orcamento;

	public Marketing(String nomeCampanha, String descricaoCampanha, double orcamento) {
		this.nomeCampanha = nomeCampanha;
		this.descricaoCampanha = descricaoCampanha;
		this.orcamento = orcamento;
	}

	public String getNomeCampanha() {
		return nomeCampanha;
	}

	public void setNomeCampanha(String nomeCampanha) {
		this.nomeCampanha = nomeCampanha;
	}

	public String getDescricaoCampanha() {
		return descricaoCampanha;
	}

	public void setDescricaoCampanha(String descricaoCampanha) {
		this.descricaoCampanha = descricaoCampanha;
	}

	public double getOrcamento() {
		return orcamento;
	}

	public void setOrcamento(double orcamento) {
		this.orcamento = orcamento;
	} 
	
	
	

}
