package com.abctreinamentos.novasfuncionalidades.service;

import java.util.List;

import com.abctreinamentos.novasfuncionalidades.entity.Funcionario;

public interface FuncionarioService {

	List<Funcionario> listAll();
	
	default void printAll() {
		List<Funcionario> funcionarios = listAll();
		init();
		funcionarios.forEach(System.out::print);	
	}
	
	static void calcularBonusFuncionario(Funcionario funcionario)
	{
		List<Double> lista = List.of(0.1,0.15,0.2);
		
		double bonus = 0;
		
		if (funcionario.salario() <= 5000)
			bonus = funcionario.salario()*lista.get(2);
		else if (funcionario.salario() <= 6000)
			bonus = funcionario.salario()*lista.get(1);
		else
			bonus = funcionario.salario()*lista.get(0);
		
		System.out.println(bonus);
	}
	
	private void init()
	{
		System.out.println("Listando os Funcionários da Aplicação");
	}
}
