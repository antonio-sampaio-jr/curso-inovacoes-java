package com.abctreinamentos.novasfuncionalidades.aux.novaversao;

public record RFinancas (String nomeTransacao, double valor) implements IDepartamento {
		
}
