package com.abctreinamentos.novasfuncionalidades.aux.novaversao;

public interface IDepartamento 
{
	
}
