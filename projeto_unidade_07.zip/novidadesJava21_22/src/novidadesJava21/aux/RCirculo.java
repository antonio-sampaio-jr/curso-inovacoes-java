package novidadesJava21.aux;

public record RCirculo(double raio) implements RForma{

}
