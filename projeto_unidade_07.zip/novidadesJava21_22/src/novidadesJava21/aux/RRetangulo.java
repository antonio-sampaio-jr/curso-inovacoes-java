package novidadesJava21.aux;

public record RRetangulo(double largura, double altura) 
					implements RForma {

}
