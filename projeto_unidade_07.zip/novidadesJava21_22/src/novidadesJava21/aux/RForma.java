package novidadesJava21.aux;

public interface RForma {

}
