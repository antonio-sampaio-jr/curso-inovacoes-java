package novidadesJava21.aux;

public abstract class Forma {

}
