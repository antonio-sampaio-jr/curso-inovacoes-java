package novidadesJava21_22;

import java.util.Arrays;
import java.util.List;
import java.util.concurrent.Executors;
import java.util.stream.Collectors;

import novidadesJava21.aux.*;

public class Java21 {

	public static void main(String[] args) {
		
		exemplo07();
	}
	
	/************** MUDANÇAS OFICIAIS ***************/
	//Unidade 07 -> Pattern Matching for Switch
	public static void exemplo01()
	{

		Forma forma = new Circulo(3); // Cria um Círculo de raio 3 
        
        double area = switch (forma) {
            case Circulo c when c.getRaio() > 0 -> Math.PI * c.getRaio() * c.getRaio();
            case Retangulo r when r.getAltura() > 0 -> r.getAltura() * r.getLargura();
            default -> throw new IllegalArgumentException("Forma desconhecida");
        };
        
        System.out.println("Área da forma: " + area);			
	}
	
	//Unidade 07 -> Record Pattern for Switch
	public static void exemplo02()
	{

			RForma forma = new RCirculo(4); // Cria um Record Círculo de raio 4 
	        
	        double area = switch (forma) {
	            case RCirculo c when c.raio() > 0 -> Math.PI * c.raio() * c.raio();
	            case RRetangulo r when r.altura() > 0 -> r.altura() * r.largura();
	            default -> throw new IllegalArgumentException("Forma desconhecida");
	        };
	        
	        System.out.println("Área da forma: " + area);			
	}
	
	//Unidade 07 -> Sequenced Collections
	public static void exemplo03()
	{
		var arrayList = List.of(1, 2, 3, 4, 5);

		// Antes - Java 17
		var ultimoItem17 = arrayList.get(arrayList.size() - 1);

		// Depois - Java 21
		var ultimoItem21 = arrayList.getLast();

		System.out.printf("Último Item: %d, %d%n", ultimoItem17, ultimoItem21);
	}
	
	//Unidade 07 -> Math.clamp
	//Se o valor estiver dentro do intervalo definido pelos limites inferior e superior, 
	//ele será retornado sem alterações. Caso contrário, se estiver fora do intervalo, 
	//será ajustado para o limite mais próximo.
	public static void exemplo04()
	{
		// Definindo um valor
		double valor = 15.0;
    
		// Definindo os limites mínimo e máximo
		double limiteMinimo = 10.0;
		double limiteMaximo = 20.0;
    
		// Utilizando o método Math.clamp para limitar o valor dentro do intervalo
		double valorLimitado = Math.clamp(valor, limiteMinimo, limiteMaximo);
    
		// Exibindo o valor limitado
		System.out.println("O valor limitado é: " + valorLimitado);
		
		/*
		 * if (value < min) {
  			value = min;
		   } else if (value > max) {
  			value = max;
		   }
		 */
	}
	
	//Unidade 07 -> Novos métodos String
	public static void exemplo05()
	{
		String string = "O meu nome é Antonio Sampaio Jr";
		String[] parts = string.splitWithDelimiters(" ", 7);
		System.out.println(Arrays.stream(parts).collect(Collectors.joining(",")));
	}	
	
	//Unidade 07 -> StringBuilder.repeat() e StringBuffer.repeat()
	public static void exemplo06()
	{
		//StringBuilder
		StringBuilder sb = new StringBuilder();
		sb.repeat("/***/", 10);
		System.out.println(sb);
		sb = new StringBuilder();
		sb.repeat(0x1f600,10);
		System.out.println(sb);
		
		//StringBuffer
		StringBuffer sbf = new StringBuffer();
		sbf.repeat("/@@@/", 10);
		System.out.println(sbf);
		sbf = new StringBuffer();
		sbf.repeat(0x1f610,10);
		System.out.println(sbf);
	}	
	
	//Unidade 07 -> Virtual Threads
	public static void exemplo07()
	{
		// Objeto Runnable "comum"
		Runnable thread = () -> System.out.printf("Olá! Estou rodando em %s \n", Thread.currentThread());

		// Execução de uma thread "comum" com o Runnable "comum"
		Executors.newSingleThreadExecutor().execute(thread);

		// Execução de uma virtual thread com o mesmo Runnable "comum"        
		Executors.newVirtualThreadPerTaskExecutor().execute(thread);		
	}	
}
