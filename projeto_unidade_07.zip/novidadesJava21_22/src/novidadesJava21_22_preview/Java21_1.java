void main(String[] args) {
    System.out.println("Texto sem Definição de Classe");
}