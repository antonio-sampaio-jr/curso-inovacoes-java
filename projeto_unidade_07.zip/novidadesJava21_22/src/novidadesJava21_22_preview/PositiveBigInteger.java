import java.math.BigInteger;

public class PositiveBigInteger extends BigInteger {

    public PositiveBigInteger(long value) {
        if (value <= 0)
            throw new IllegalArgumentException("O valor não é positivo!");
        super(Long.toString(value));
    }

    public static void main(String[] args) {
        PositiveBigInteger pbi = new PositiveBigInteger(10);
    }
}