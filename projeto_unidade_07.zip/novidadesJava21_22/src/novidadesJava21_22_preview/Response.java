public class Response {
    private String user;
    private int order;

    public Response(String user, int order) {
        this.user = user;
        this.order = order;
    }

    // Métodos getters e setters
    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public int getOrder() {
        return order;
    }

    public void setOrder(int order) {
        this.order = order;
    }
}
