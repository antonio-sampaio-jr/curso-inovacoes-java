import java.util.concurrent.*;

public class Java21 {

	public static ScopedValue<String> scopedValue = ScopedValue.newInstance();

	public static void main(String[] args) throws Exception{
		
		exemplo12();
	}

    /************** PREVIEW ***************/
	//Unidade 07 -> Unnamed Variables
	public static void exemplo08()
	{
		var string = "10";
		try {
			  int x = Integer.parseInt(string);
              System.out.println(x);
			} 
		catch (NumberFormatException _) { 
			  System.err.println("Não é um número");
			}
		
	}

    //Unidade 07 -> String Templates
	public static void exemplo09()
	{
        var name = "Antonio";

        // Antes - Java 17
        System.out.printf("Olá, %s%n", name);

        // Depois - Java 21
        System.out.println(STR."Olá, \{name}");  

        var texto = STR."Olá \{name}. Seja bem-vindo!";  
        System.out.println(texto);    
    }

	//Unidade 07 -> Scoped Values
	public static void exemplo10()
	{
		ScopedValue.runWhere(scopedValue, "Antonio Sampaio Jr", () -> {
			System.out.println("Valor é: " + scopedValue.get());
			System.out.println("Acessando o valor <scoped value>: " + scopedValue.get());
	    });
		
		ScopedValue.runWhere(scopedValue, "Antonio Benedito", () -> {
			System.out.println("Valor é: " + scopedValue.get());
			System.out.println("Acessando o valor <scoped value>: " + scopedValue.get());
	    });
	}

	//Unidade 07 -> Concorrência Não Estruturada
	public static void exemplo11()
	{
		try(ExecutorService executorService = Executors.newVirtualThreadPerTaskExecutor()) {
			getResponse(executorService);
		} catch (ExecutionException | InterruptedException e) {
			System.out.println("Sub task exception caught!");
		}
	}
	//Unidade 07 -> Concorrência Não Estruturada
	private static Response getResponse(ExecutorService executorService) throws ExecutionException, InterruptedException {
		Future<String> user = executorService.submit(() -> findUser());
		Future<Integer> order = executorService.submit(() -> fetchOrder());
		String theUser = user.get();
		int theOrder = order.get();
		return new Response(theUser, theOrder);
	}
	//Unidade 07 -> Concorrência Não Estruturada
	private static String findUser() throws InterruptedException {
		Thread.sleep(1000);
		System.out.println("findUser() running!");
		return "user";
	}
	//Unidade 07 -> Concorrência Não Estruturada
	private static int fetchOrder() throws InterruptedException {
		Thread.sleep(2000);
		System.out.println("fetchOrder() running!");
		return 100;
	}
	//Unidade 07 -> Concorrência Estruturada
	public static void exemplo12()
	{
		try(ExecutorService executorService = Executors.newVirtualThreadPerTaskExecutor()) {
			getNewResponse();
		} catch (Exception _) {
			System.out.println("Sub task exception caught!");
		}
	}
	//Unidade 07 -> Concorrência Estruturada
	private static Response getNewResponse() {
		try (var scope = new StructuredTaskScope.ShutdownOnFailure()) {

			var userFuture = scope.fork(() -> findUser());
			var orderFuture = scope.fork(() -> fetchOrder());
	
			scope.join();
	
			return new Response(userFuture.get(), orderFuture.get());
		} 
		catch (InterruptedException e) {
			throw new RuntimeException(e);
		}
	}

}    