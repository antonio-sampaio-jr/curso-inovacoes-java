/**
 *
 * @author antoniobcsampaiojr
 */
import java.util.List;
import java.util.stream.Gatherers;
public class Java22 {
    
    public static void main(String[] args) {
        System.out.printf(OutraClasseJava22.alo(args[0]));
        //exemplo02();
    }

    /**
     *
     */
    public static void exemplo01()
    {
        List<String> words = List.of("the", "be", "two", "of", "and", "a", "in", "that");

        List<List<String>> fixedWindows = words.stream()
            .gather(Gatherers.windowFixed(3))
            .toList();
        
        System.out.println(fixedWindows);
    }

    public static void exemplo02()
    {
        List<Integer> numbers = List.of(1, 2, 3, 4, 5);

        List<List<Integer>> slidingWindows = numbers.stream()
            .gather(Gatherers.windowSliding(3))
            .toList();

        System.out.println(slidingWindows);
    }

}
