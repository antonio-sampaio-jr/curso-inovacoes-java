public class OutraClasseJava22 {
    public static String alo(String name) {
      return "Alo %s!%n".formatted(name);
    }
  }
