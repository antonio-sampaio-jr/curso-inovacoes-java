package com.abctreinamentos.novasfuncionalidades;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NovasfuncionalidadesApplicationTests {

	@Test
	void contextLoads() {
	}

}
