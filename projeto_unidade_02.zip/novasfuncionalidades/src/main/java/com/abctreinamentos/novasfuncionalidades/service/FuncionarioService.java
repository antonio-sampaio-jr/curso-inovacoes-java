package com.abctreinamentos.novasfuncionalidades.service;

import java.util.List;

import com.abctreinamentos.novasfuncionalidades.entity.Funcionario;

public interface FuncionarioService {

	List<Funcionario> listAll();
	
}
