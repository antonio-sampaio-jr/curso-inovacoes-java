package novidadesJava14.aux;

public class PessoaFisica extends Pessoa {

	private String cpf;
	
	public PessoaFisica(String nome, int idade) {
		super(nome, idade);
		// TODO Auto-generated constructor stub
	}
	
	public PessoaFisica(String nome, int idade, String cpf) {
		super(nome, idade);
		this.cpf = cpf;
		// TODO Auto-generated constructor stub
	}

	public String getCpf() {
		return cpf;
	}

	public void setCpf(String cpf) {
		this.cpf = cpf;
	}
	
	

}
