package novidadesJava14.aux;

public class PessoaHolding extends Pessoa {

	public PessoaHolding(String nome) {
		super(nome);
		// TODO Auto-generated constructor stub
	}

}
