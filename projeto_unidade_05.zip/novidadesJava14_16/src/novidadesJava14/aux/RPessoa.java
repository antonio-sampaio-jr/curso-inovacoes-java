package novidadesJava14.aux;

public record RPessoa(String nome, int idade) {

}
