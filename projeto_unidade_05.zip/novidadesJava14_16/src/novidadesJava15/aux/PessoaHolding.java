package novidadesJava15.aux;

public final class PessoaHolding extends Pessoa {

	public PessoaHolding(String nome) {
		super(nome);
		// TODO Auto-generated constructor stub
	}

}
