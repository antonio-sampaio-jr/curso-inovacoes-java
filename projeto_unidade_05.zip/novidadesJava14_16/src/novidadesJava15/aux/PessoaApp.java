package novidadesJava15.aux;

public class PessoaApp {

	public static void main(String[] args) {
		
		Pessoa pessoa = new PessoaJuridica("Empresa X", "12345678901234");

        if (pessoa instanceof PessoaFisica pf) {
            System.out.println(pf.getNome() + " é uma Pessoa Física com CPF: " + pf.getCpf());
        } else if (pessoa instanceof PessoaJuridica pj) {
            System.out.println(pj.getNome() + " é uma Pessoa Jurídica com CNPJ: " + pj.getCnpj());
        } else {
            System.out.println(pessoa.getNome() + " é uma Pessoa.");
        }

	}

}
