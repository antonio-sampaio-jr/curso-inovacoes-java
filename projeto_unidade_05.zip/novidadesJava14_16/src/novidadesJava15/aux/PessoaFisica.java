package novidadesJava15.aux;

public final class PessoaFisica extends Pessoa {

	private String cpf;
	
	public PessoaFisica(String nome, int idade) {
		super(nome, idade);
		// TODO Auto-generated constructor stub
	}

	public String getCpf() {
		return cpf;
	}

	public void setCpf(String cpf) {
		this.cpf = cpf;
	}
	
	

}
