package novidadesJava14_16;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Java16 {

	public static void main(String[] args) {
		exemplo01();
	}
	
	//Unidade 05 -> Pattern Matching -> Slide 19
	public static void exemplo01()
	{
		String novoFuncionario = """
				{
				"nome": "Pedro Ramos",
				"idade": 37,
				"cargo": "Engenheiro de Software",
				"departamento": "IT",
				"salario": 10000.00,
				"endereco": {
				  "rua": "Avenida Nazaré",
				  "numero": 33,
				  "cidade": "Belém",
				  "estado": "PA",
				  "cep": "66050-180"
				}
				"""; 
		
		Pattern padraoProcurado = Pattern.compile("IT",Pattern.CASE_INSENSITIVE);
		Matcher padraoEncontrado = padraoProcurado.matcher(novoFuncionario);
		
		while(padraoEncontrado.find())
		{
			System.out.println("Achou:"+padraoEncontrado.group());
			System.out.println("Inicia na posição:"+padraoEncontrado.start());
			System.out.println("Termina na posição:"+padraoEncontrado.end());
		}
	}

}
