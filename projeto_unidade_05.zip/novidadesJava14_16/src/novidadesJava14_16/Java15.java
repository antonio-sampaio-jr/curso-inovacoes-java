package novidadesJava14_16;

import novidadesJava14.aux.Pessoa;
import novidadesJava14.aux.PessoaFisica;
import novidadesJava14.aux.PessoaJuridica;

public class Java15 {

	public static void main(String[] args) {
		exemplo01();
	}
	
	//Unidade 05 -> Classes Sealed -> Slide 15
	public static void exemplo01()
	{
		Pessoa pessoa = new Pessoa("Antonio", 47);
		Pessoa pessoaf = new PessoaFisica("Pedro", 35);
		Pessoa pessoaj = new PessoaJuridica("Empresa X", "12345678901234");
		
		System.out.println(pessoa);
	}
}
