package novidadesJava14_16;

import novidadesJava14.aux.Pessoa;
import novidadesJava14.aux.PessoaFisica;
import novidadesJava14.aux.PessoaJuridica;
import novidadesJava14.aux.RPessoa;

public class Java14 {

	public static void main(String[] args) {
		
		exemplo03();
	}
	
	//Unidade 05 -> Records -> Slide 7
	public static void exemplo01()
	{
		Pessoa pessoa = new Pessoa("Antonio",47);
		System.out.println(pessoa.getNome()+"<==>"+pessoa.getIdade());
		System.out.println(pessoa);
		pessoa.setNome("Antonio Sampaio");
		System.out.println(pessoa.getNome()+"<==>"+pessoa.getIdade());
		
		RPessoa rpessoa = new RPessoa("Pedro",37);
		System.out.println(rpessoa.nome()+"<==>"+rpessoa.idade());
		System.out.println(rpessoa);
	}
	
	//Unidade 05 -> Pattern Matching para InstanceOf -> Slide11
	public static void exemplo02()
	{
		//Pessoa pessoa = new PessoaJuridica("Empresa X", "12345678901234");
		Pessoa pessoa = new PessoaFisica("Antonio Sampaio", 47,"123.456.789-01");

        if (pessoa instanceof PessoaFisica pf) {
            System.out.println(pf.getNome() + " é uma Pessoa Física com CPF: " + pf.getCpf());
        } else if (pessoa instanceof PessoaJuridica pj) {
            System.out.println(pj.getNome() + " é uma Pessoa Jurídica com CNPJ: " + pj.getCnpj());
        } else {
            System.out.println(pessoa.getNome() + " é uma Pessoa.");
        }
	}

	//Unidade 05 -> HelpFul NPE -> Slide12
	public static void exemplo03()
	{
		String texto = null;
        int comprimento = texto.length(); // Isso vai gerar um NullPointerException		
	}

}
