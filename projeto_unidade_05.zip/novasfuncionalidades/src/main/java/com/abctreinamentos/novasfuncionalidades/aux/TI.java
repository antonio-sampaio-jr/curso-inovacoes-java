package com.abctreinamentos.novasfuncionalidades.aux;

public final class TI extends Departamento {
	
	private String nomeProjeto;
    private String responsavelProjeto;
    
	public TI(String nomeProjeto, String responsavelProjeto) {
		super();
		this.nomeProjeto = nomeProjeto;
		this.responsavelProjeto = responsavelProjeto;
	}

	public String getNomeProjeto() {
		return nomeProjeto;
	}

	public void setNomeProjeto(String nomeProjeto) {
		this.nomeProjeto = nomeProjeto;
	}

	public String getResponsavelProjeto() {
		return responsavelProjeto;
	}

	public void setResponsavelProjeto(String responsavelProjeto) {
		this.responsavelProjeto = responsavelProjeto;
	}
    
    
    

}
