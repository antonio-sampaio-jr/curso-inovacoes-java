package com.abctreinamentos.novasfuncionalidades.controller;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.time.LocalDate;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.abctreinamentos.novasfuncionalidades.aux.Departamento;
import com.abctreinamentos.novasfuncionalidades.aux.Design;
import com.abctreinamentos.novasfuncionalidades.aux.Financas;
import com.abctreinamentos.novasfuncionalidades.aux.Marketing;
import com.abctreinamentos.novasfuncionalidades.aux.TI;
import com.abctreinamentos.novasfuncionalidades.aux.Vendas;
import com.abctreinamentos.novasfuncionalidades.entity.Funcionario;
import com.abctreinamentos.novasfuncionalidades.service.FuncionarioService;

@RestController
public class FuncionarioController {
	
	@Autowired
	private FuncionarioService funcionarioService;
	
	@GetMapping("/")
	public ResponseEntity<String> inicio()
	{
		String response = """
				<html>
					<body>
						<a href="/listarFuncionarios">1. Listar Funcionários</a> <br />
						<a href="/listarCidadesFuncionarios">2. Listar Cidades Funcionários</a> <br />
						<a href="/calcularFolhaFuncionarios">3. Calcular Folha Funcionários</a> <br />
						<a href="/listarFuncionariosIdadeMenor30">4. Listar Funcionários Idade < 30</a> <br />
						<a href="/listarFuncionariosIdadeMaiorIgual30">4. Listar Funcionários Idade >= 30</a> <br />
					    <a href="/listarFuncionarioMaiorSalario">5. Listar Funcionário Maior Salário</a> <br />
					    <a href="/listarFuncionarioMenorSalario">6. Listar Funcionário Menor Salário</a> <br />
					    <a href="/listarSalariosFuncionariosOrdenados">7. Listar Salários Funcionários Ordenados</a> <br />
					    <a href="/listarAnoNascimentoFuncionarioMaisAntigo">8. Listar Ano Funcionário Mais Antigo</a> <br /> 	    
		                <a href="/listarSalariosFuncionariosOrdenadosSimplificado">9. Listar Salários Funcionários Ordenados - Simplificado</a> <br />		
					    <a href="/inserirNovoFuncionarioJSON">10. Inserir Novo Funcionário JSON</a><br />
					    <a href="/listarAtividadesFuncionarios">11. Listar Atividades Funcionários</a><br />
					    <a href="/listarAtividadesFuncionariosDetalhadamente">12. Listar Atividades Funcionários Detalhadamente</a><br /> 
					    <a href="/listarFuncionariosTrabalhoRemoto">13. Listar Funcionários Trabalho Remoto</a><br /> 
					</body>
				</html>
				""";
		
		return new ResponseEntity<String>(response,HttpStatus.OK);	
	}
	
	@GetMapping("/listarFuncionarios")
	public ResponseEntity<List<Funcionario>> listarFuncionarios()
	{
		List<Funcionario> funcionarios = funcionarioService.listAll();
		return new ResponseEntity<List<Funcionario>>(funcionarios,HttpStatus.OK);	
	}
	
	@GetMapping("/listarCidadesFuncionarios")
	public ResponseEntity<List<String>> listarCidadesFuncionarios()
	{
		var funcionarios = funcionarioService.listAll();
		
	    var cidades = funcionarios.stream().map(Funcionario::cidade).toList();
		
		return new ResponseEntity<List<String>>(cidades,HttpStatus.OK);	
	}
	
	@GetMapping("/calcularFolhaFuncionarios")
	public ResponseEntity<String> calcularFolhaFuncionarios()
	{
		List<Funcionario> funcionarios = funcionarioService.listAll();
		
		double somaSalarios = funcionarios.stream().mapToDouble(Funcionario::salario).sum();
		
		//Java 13 -> Text Blocks
		String resposta = """
				{
					"Total da Folha de Pagamentos": %.2f
				}
				""".formatted(somaSalarios);
		
		
		return new ResponseEntity<String>(resposta,HttpStatus.OK);	
	}
	
	@GetMapping("/listarFuncionariosIdadeMenor30")
	public ResponseEntity<String> listarFuncionariosIdadeMenor30()
	{
		List<Funcionario> funcionarios = funcionarioService.listAll();
		
		long totalFuncionarios = funcionarios.stream().filter(f -> f.idade() < 30).count();
		double somaSalarios = funcionarios.stream().
				filter(f -> f.idade() < 30).mapToDouble(Funcionario::salario).sum();
		
		double mediaSalarial = somaSalarios/totalFuncionarios;
		
		//Java 13 -> Text Blocks
		String resposta = """
				{
					"Total de Funcionários < 30 anos": %d,
					"Média Salarial": %.2f
				}
				""".formatted(totalFuncionarios,mediaSalarial);
		
		
		return new ResponseEntity<String>(resposta,HttpStatus.OK);	
	}
	
	@GetMapping("/listarFuncionariosIdadeMaiorIgual30")
	public ResponseEntity<String> listarFuncionariosIdadeMaiorIgual30()
	{
		List<Funcionario> funcionarios = funcionarioService.listAll();
		
		long totalFuncionarios = funcionarios.stream().filter(f -> f.idade() >= 30).count();
		double somaSalarios = funcionarios.stream().
				filter(f -> f.idade() >= 30).mapToDouble(Funcionario::salario).sum();
		
		double mediaSalarial = somaSalarios/totalFuncionarios;
		
		//Java 13 -> Text Blocks
		String resposta = """
				{
					"Total de Funcionários >= 30 anos": %d,
					"Média Salarial": %.2f
				}
				""".formatted(totalFuncionarios,mediaSalarial);
		
		
		return new ResponseEntity<String>(resposta,HttpStatus.OK);	
	}
	
	@GetMapping("/listarFuncionarioMaiorSalario")
	public ResponseEntity<Optional<Funcionario>> listarFuncionarioMaiorSalario()
	{
		List<Funcionario> funcionarios = funcionarioService.listAll();
		
		Optional<Funcionario> funcionario = funcionarios.stream().
				reduce((f1,f2)->f1.salario()>f2.salario() ? f1:f2);
		
		return new ResponseEntity<Optional<Funcionario>>(funcionario,HttpStatus.OK);	
	}
	
	@GetMapping("/listarFuncionarioMenorSalario")
	public ResponseEntity<Optional<Funcionario>> listarFuncionarioMenorSalario()
	{
		List<Funcionario> funcionarios = funcionarioService.listAll();
		
		Optional<Funcionario> funcionario = funcionarios.stream().
				reduce((f1,f2)->f1.salario() < f2.salario() ? f1:f2);
		
		return new ResponseEntity<Optional<Funcionario>>(funcionario,HttpStatus.OK);	
	}
	
	@GetMapping("/listarSalariosFuncionariosOrdenados")
	public ResponseEntity<List<Funcionario>> listarSalariosFuncionariosOrdenados()
	{
		List<Funcionario> funcionarios = funcionarioService.listAll().stream().
				sorted((f1,f2)->Double.compare(f1.salario(), f2.salario())).toList();
		
		return new ResponseEntity<List<Funcionario>>(funcionarios,HttpStatus.OK);	
	}
	
	@GetMapping("/listarSalariosFuncionariosOrdenadosSimplificado")
	public ResponseEntity<Map<?,?>> listarSalariosFuncionariosOrdenadosSimplificado()
	{
		List<Funcionario> funcionarios = funcionarioService.listAll().stream().
				sorted((f1,f2)->Double.compare(f1.salario(), f2.salario())).toList();
		
		var nomeSalarioMap = new LinkedHashMap<>();
		
		funcionarios.forEach(funcionario -> nomeSalarioMap.put(funcionario.nome(),funcionario.salario()));
		
		return new ResponseEntity<>(nomeSalarioMap,HttpStatus.OK);	
	}
	
	@GetMapping("/listarAnoNascimentoFuncionarioMaisAntigo")
	public ResponseEntity<String> listarAnoNascimentoFuncionarioMaisAntigo()
	{
		var funcionarios = funcionarioService.listAll();
		
		Optional<Funcionario> funcionario = funcionarios.stream().
				reduce((f1,f2)->f1.idade() > f2.idade() ? f1:f2);
		
		int maiorIdade = 0;
		String nome = "";
		
		if(funcionario.isPresent())
		{
			maiorIdade = funcionario.get().idade();
			nome = funcionario.get().nome();
		}	
		
		LocalDate dataHoje = LocalDate.now();
        
        int anoNascimentoProvavel = dataHoje.getYear() - maiorIdade;
      
        String resposta = """
				{
					"Nome do Funcionário Mais Antigo": %s,
					"Provável Ano de Nascimento": %d
				}
				""".formatted(nome,anoNascimentoProvavel);
		
		
		return new ResponseEntity<String>(resposta,HttpStatus.OK);
	}
	
	@GetMapping("/inserirNovoFuncionarioJSON")
	public ResponseEntity<String> inserirNovoFuncionarioJSON()
	{
		var funcionarios = funcionarioService.listAll();
		
		String resposta = "";
		
		try {
			String novoFuncionario = """
					{
					"nome": "Pedro Ramos",
					"idade": 37,
					"cargo": "Engenheiro de Software",
					"departamento": "IT",
					"salario": 10000.00,
					"endereco": {
					  "rua": "Avenida Nazaré",
					  "numero": 33,
					  "cidade": "Belém",
					  "estado": "PA",
					  "cep": "66050-180"
					}
					"""; 
			Files.writeString(Path.of("/Users/verenasampaio/Downloads/novasfuncionalidades 2/src/main/resources/data/funcionarios.json"),
					novoFuncionario,StandardOpenOption.APPEND);
			
			resposta = Files.readString(Path.of("/Users/verenasampaio/Downloads/novasfuncionalidades 2/src/main/resources/data/funcionarios.json"));
			
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return new ResponseEntity<String>(resposta,HttpStatus.OK);
	}
	
	@GetMapping("/listarAtividadesFuncionarios")
	public ResponseEntity<Map<?,?>> listarAtividadesFuncionarios()
	{
		List<Funcionario> funcionarios = funcionarioService.listAll();
		
		var nomeAtividadeMap = new LinkedHashMap<>();
		
		funcionarios.forEach(funcionario -> {
		
			String atividade = switch(funcionario.departamento())
			{
				case "Marketing" -> "Atividade Principal ==> Realizar Divulgação";
				case "Vendas" -> "Atividade Principal ==> Realizar Vendas";
				case "Tecnologia da Informação" -> "Atividade Principal ==> Manter o Parque Computacional Funcionando";
				case "Finanças" -> "Atividade Principal ==> Administrar o Fluxo de Caixa";
				case "Design" -> "Atividade Principal ==> Responsável pelo Design dos Produtos";
				default -> "Ação Não Definida";
			
			};
			nomeAtividadeMap.put(funcionario.nome(),atividade);
		});
		return new ResponseEntity<>(nomeAtividadeMap,HttpStatus.OK);	
	}	
	
	@GetMapping("/listarAtividadesFuncionariosDetalhadamente")
	public ResponseEntity<Map<?,?>> listarAtividadesFuncionariosDetalhadamente()
	{
		List<Funcionario> funcionarios = funcionarioService.listAll();
		
		var nomeAtividadeMap = new LinkedHashMap<>();
		
		funcionarios.forEach(funcionario -> {
		
			Departamento atividade = switch(funcionario.departamento())
			{
				case "Marketing" -> {
					yield new Marketing("Venda pela Internet","Realizar 1000 vendas em 24h",10000);
				}
				case "Vendas" -> {
					yield new Vendas("Motos",15000);
				}
				case "Tecnologia da Informação" -> {
					yield new TI("Modernização de Atendimento ao Cliente",funcionario.nome());
				}
				case "Finanças" -> {
					yield new Financas("Venda",15000);
				}
				case "Design" -> {
					yield new Design("Moto 150 cc","Moto vermelha com carenagem preta");
				}
				default -> null;
			
			};
			nomeAtividadeMap.put(funcionario.nome(),atividade);
		});
		return new ResponseEntity<>(nomeAtividadeMap,HttpStatus.OK);	
	}	
	
	@GetMapping("/listarFuncionariosTrabalhoRemoto")
	public ResponseEntity<Map<?,?>> listarFuncionariosTrabalhoRemoto()
	{
		List<Funcionario> funcionarios = funcionarioService.listAll();
		
		var nomeModalidadeMap = new LinkedHashMap<>();
		
		Pattern padraoProcurado = Pattern.compile("Presencial");
		
		funcionarios.forEach(funcionario -> {
		
			Matcher padraoEncontrado = padraoProcurado.matcher(funcionario.formatoTrabalho());
			
			if (padraoEncontrado.matches())
				nomeModalidadeMap.put(funcionario.nome(),funcionario.formatoTrabalho());
		});
		return new ResponseEntity<>(nomeModalidadeMap,HttpStatus.OK);	
	}	
	
}
