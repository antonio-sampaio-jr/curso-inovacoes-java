package com.abctreinamentos.novasfuncionalidades.aux;

public final class Financas extends Departamento {

	private String nomeTransacao;
    private double valor;
    
	public Financas(String nomeTransacao, double valor) {
		super();
		this.nomeTransacao = nomeTransacao;
		this.valor = valor;
	}
	
	public String getNomeTransacao() {
		return nomeTransacao;
	}
	public void setNomeTransacao(String nomeTransacao) {
		this.nomeTransacao = nomeTransacao;
	}
	public double getValor() {
		return valor;
	}
	public void setValor(double valor) {
		this.valor = valor;
	}
    
	
	
}
