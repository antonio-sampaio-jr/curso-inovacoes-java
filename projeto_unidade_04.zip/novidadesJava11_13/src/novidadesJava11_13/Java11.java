package novidadesJava11_13;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.function.BiFunction;
import java.util.function.Predicate;

//Criando anotações personalizadas
@interface Nonnull {}
@interface Nullable {}

public class Java11 {

	public static void main(String[] args) {
		exemplo07();
		exemplo06();
		
	}

	//Unidade 04 -> Novos métodos String -> isBlank -> Slide 9
	public static void exemplo01()
	{
		String str1 = ""; // String vazia
		String str2 = "   "; // String com espaços em branco

		System.out.println(str1.isBlank()); // true
		System.out.println(str2.isBlank()); // true
	}
	
	//Unidade 04 -> Novos métodos String -> strip -> Slide 10
	public static void exemplo02()
	{
		String str = "   	Olá, mundo!   	";
		String resultado = str.strip();

		System.out.println(resultado); // "Olá, mundo!"

	}
	
	//Unidade 04 -> Novos métodos String -> lines -> Slide 11
	public static void exemplo03()
	{
		String texto = "Primeira linha\nSegunda linha\nTerceira linha";
		texto.lines().forEach(System.out::println);
	}
	
	//Unidade 04 -> Novos métodos String -> repeat -> Slide 12
	public static void exemplo04()
	{
		String str = "Java ";
		String repeticao = str.repeat(10);

		System.out.println(repeticao); // "Java Java Java "	
	}
	
	//Unidade 04 -> Var nos parâmetros Lambda -> Slide 13
	public static void exemplo05()
	{	
		BiFunction<@Nonnull String, @Nullable String, String> concatenar = (s1, s2) -> {
        
			if (s2 == null) {
            	return s1;
        	} else {
            	return s1 + s2;
        	}
		};

		String resultado1 = concatenar.apply("Olá, ", null);
		String resultado2 = concatenar.apply("Java ", "11");

		System.out.println(resultado1); // "Olá, "
		System.out.println(resultado2); // "Java 11"
		
		Predicate<Integer> maiorQueDez = (var x) -> x > 10;
		
		System.out.println(maiorQueDez.test(5));  // Saída: false
        System.out.println(maiorQueDez.test(15)); // Saída: true

	}
	
	//Unidade 04 -> Novo método leitura em Arquivos -> Slide 14
	public static void exemplo06()
	{
		try {
			String texto = Files.readString(Path.of("/Users/verenasampaio/Documents/projetosCursoInovacoesJava/novidadesJava11_13/src/novidadesJava11_13/funcionarios.json"));
			System.out.println(texto);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	//Unidade 04 -> Novo método escrita em Arquivos -> Slide 14
	public static void exemplo07()
	{
		try {
			String novoFuncionario = """
					{
					"nome": "Pedro Ramos",
					"idade": 37,
					"cargo": "Engenheiro de Software",
					"departamento": "IT",
					"salario": 10000.00,
					"endereco": {
					  "rua": "Avenida Nazaré",
					  "numero": 33,
					  "cidade": "Belém",
					  "estado": "PA",
					  "cep": "66050-180"
					}
					"""; 
			Files.writeString(Path.of("/Users/verenasampaio/Documents/projetosCursoInovacoesJava/novidadesJava11_13/src/novidadesJava11_13/funcionarios.json"),
					novoFuncionario,StandardOpenOption.APPEND);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
}
