package novidadesJava11_13;

import java.util.Calendar;

public class Java13 {

	public static void main(String[] args) {
		exemplo02();

	}
	
	//Unidade 04 -> Text Blocks -> Slide 19
	public static void exemplo01()
	{
		String textoMultilinha = """
				Este é um exemplo
				de texto multilinha
				usando text blocks.
				""";
				
		System.out.println(textoMultilinha);
	}
	
	//Unidade 04 -> Yields -> Slide 20
	public static void exemplo02()
	{
		int day = Calendar.getInstance().get(Calendar.DAY_OF_WEEK);

		int dia = switch(day) {
		case Calendar.MONDAY -> {
			System.out.println("Segunda-feira");
			yield 1;
		}
		case Calendar.TUESDAY -> 2;
		case Calendar.WEDNESDAY -> {
			System.out.println("Quarta-feira");
			yield 3;
		}
		case Calendar.THURSDAY -> 4;
		case Calendar.FRIDAY -> 5;
		default -> 0;

		};
		System.out.println(dia);
	}
}
