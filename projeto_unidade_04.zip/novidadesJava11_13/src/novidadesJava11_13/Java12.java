package novidadesJava11_13;

import java.util.Calendar;

public class Java12 {

	public static void main(String[] args) {
		exemplo03();

	}
	
	//Unidade 04 -> Novos métodos String -> indent -> Slide 15
	public static void exemplo01()
	{
        String multilineStr = "This is\na multiline\nstring.";
        String outputStr = "   This is\n   a multiline\n   string.\n";

        String postIndent = multilineStr.indent(3);
        System.out.println(postIndent);
        System.out.println(outputStr);
	}
	
	//Unidade 04 -> Novos métodos String -> transform -> Slide 16
	public static void exemplo02()
	{
		String result = "hello".transform(input -> input + " world!");
		System.out.println(result);
	}
	
	//Unidade 04 -> Switch Expressions -> Slide 17
	public static void exemplo03()
	{
		int day = Calendar.getInstance().get(Calendar.DAY_OF_WEEK);
		
		boolean isWeekend = switch (day) 
		{
			case Calendar.SATURDAY, Calendar.SUNDAY -> true;
			default -> false;
		};
		
		System.out.println(isWeekend);
	}

}
